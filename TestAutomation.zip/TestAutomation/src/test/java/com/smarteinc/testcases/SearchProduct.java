package com.smarteinc.testcases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.smarteinc.base.globalLibrary;
import com.smarteinc.pages.HomePage;

public class SearchProduct extends globalLibrary
{
	globalLibrary seleniumLibrary = new globalLibrary();
	HomePage homePage = new HomePage();

	@Test(priority=1)
	public void searchProduct() throws IOException, Exception
	{
		excel.testRunMode("Search_Product");
		String testScenario = excel.getCellData("test_suite", "TestScenario", 2); //Name of the Test Scenario.
		test.log(LogStatus.PASS, "Name of Test Scenario:   " + testScenario);
		log.debug("Name of Test Scenario:   "  + testScenario);

		seleniumLibrary.navigatedURL();	//Navigate to the URL
		seleniumLibrary.click("searchPopup_XPATH"); //Click on the Pop-up Window.
		seleniumLibrary.isElementPresent("searchPopupCloseButton_XPATH"); 
		seleniumLibrary.click("searchPopupCloseButton_XPATH");  //Click on the Close button to close the Pop-up Window.

		homePage.searchProduct();
		homePage.filterPrice();
		seleniumLibrary.isElementPresent("searchCheckRAM_XPATH");
		Thread.sleep(3000);
		seleniumLibrary.webElementClick("searchCheckRAM_XPATH");
		
		homePage.selectProcessorBrand();
		homePage.setProductDetails();
	}

	@AfterMethod
	public void afterMethod() throws IOException 
	{
		driver.close();
		log.debug("Browser Closed");
		test.log(LogStatus.INFO, "**Browser Closed !!! **");
	
		log.debug("**********************  Test Execution Completed !!! ******************************");
		test.log(LogStatus.INFO, "**********************  Test Execution Completed !!! ******************************");
	}
}
