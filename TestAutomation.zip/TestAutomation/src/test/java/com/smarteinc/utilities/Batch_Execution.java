package com.smarteinc.utilities;

import java.io.IOException;
import org.testng.annotations.Test;

import com.smarteinc.base.globalLibrary;

public class Batch_Execution extends globalLibrary
{
	@Test(priority=87)
	public void batch_Execution() throws IOException, Exception
	{
		
		excel.xmlRunMode("testng.xml", "testng");
		
			
		
	}
}
