package com.smarteinc.utilities;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFHyperlink;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.SkipException;
import org.testng.TestNG;

import com.relevantcodes.extentreports.LogStatus;
import com.smarteinc.base.TestBase;
//@author #Biswajit Pattanaik
public class ExcelReader extends TestBase
{
	public  static String path;
	public  static FileInputStream fis = null;
	public  static FileOutputStream fileOut =null;
	private static XSSFWorkbook workbook = null; //Excel WorkBook
	private static XSSFSheet sheet = null;  //Excel Sheet
	private static XSSFRow row   =null; //Excel row
	private static XSSFCell cell = null;  //Excel cell
	public static CellStyle hlink_style;
	public static Map<String, Object> ColumnDictionary;

	public ExcelReader(String path) 
	{
		this.path=path;
		try {
			fis = new FileInputStream(path);
			workbook = new XSSFWorkbook(fis);
			sheet = workbook.getSheetAt(0);
			fis.close();
		} catch (Exception e) {

			e.printStackTrace();
		} 
	}

	// returns the row count in a sheet
	public int getRowCount(String sheetName)
	{
		int index = workbook.getSheetIndex(sheetName);
		if(index==-1)
			return 0;
		else{
			sheet = workbook.getSheetAt(index);
			int number=sheet.getLastRowNum()+1;
			return number;
		}

	}

	public void testRunMode(String testCaseName) 
	{
		ExcelReader testSuite= new ExcelReader(inputdata);
		int rowCount = testSuite.getRowCount("test_suite");
		int colCount = testSuite.getColumnCount("test_suite");

		int rNum=1;
		for( rNum=1; rNum<=rowCount; rNum++) 
		{
			String TCID=excel.getCellData("test_suite", "TCID", rNum);
			if(TCID.equals(testCaseName))
			{
				String runMode=excel.getCellData("test_suite", "runmode", rNum);
				if(runMode.equals("Y"))
				{
					test.log(LogStatus.INFO, "Test Case ID:   " + testCaseName.toUpperCase());
					log.debug("Test Case ID:   "  + testCaseName.toUpperCase());
					break;
				}
				else
				{
					throw new SkipException("Skipping the test case: ---   "  + testCaseName.toUpperCase()  +  "  ---   as the current run mode for data set is No");
				}

			}
		}
	}
	
	public void xmlRunMode(String xmlrunMode, String xmlFile) 
	{
		ExcelReader testSuite= new ExcelReader(inputdata);
		int rowCount = testSuite.getRowCount("Super_Suite");
		int colCount = testSuite.getColumnCount("Super_Suite");
		int xmlNum=2;
		
		for(xmlNum=2; xmlNum<=rowCount; xmlNum++) 
		{
			String suiteName=excel.getCellData("Super_Suite", "suiteName", xmlNum);
			if(suiteName.equals(xmlrunMode))
			{
				String runMode=excel.getCellData("Super_Suite", "runMode", xmlNum);
				if(runMode.equals("Y"))
				{
					TestNG runXML = new TestNG();
					List<String> list = new ArrayList<String>();
					String xml_Path = System.getProperty("user.dir") + "\\src\\test\\resources\\runner\\" +xmlFile+".xml";
					list.add(xml_Path);
					runXML.setTestSuites(list);
					runXML.run();
					test.log(LogStatus.INFO, "Name of the suite:   " + xmlrunMode.toUpperCase());
					log.debug("Name of the suite:   "  + xmlrunMode.toUpperCase());
					break;
				}
				else
				{
					test.log(LogStatus.SKIP, "Skipping the test suite: ---   "  + '\t' +xmlrunMode.toUpperCase()  +  "  ---   as the current run mode for data set is 'No' ");
					log.debug("Skipping the test suite: ---   " + '\t' + xmlrunMode.toUpperCase()  +  "  ---   as the current run mode for data set is 'No' ");
				}

			}
		}
	}
	
	// returns the row count in a sheet
	public Objects[][] getDataOnStartingPoint(String excellocation,String sheetName, String testName)
	{
		try
		{
			String[][] dataSets = null;

			int totalRow = sheet.getLastRowNum();
			int totalColumn = 0;
			//Itrate through each rows one by one.
			Iterator<Row>  rowIterator = sheet.iterator();
			int i = 0;
			int count = 1;

			while(rowIterator.hasNext() && count == 1 || count == 2)
			{
				Row row = rowIterator.next();
				//For each row, itrate through all the columns
				Iterator<Cell>  cellIterator = row.cellIterator();
				int j = 0;
				while(cellIterator.hasNext())
				{
					Cell cell = cellIterator.next();

					if(cell.getStringCellValue().contains(testName + "end"))
					{
						count = 0;
						break;
					}

					//System.out.println(sheetName + "start");
					if (cell.getStringCellValue().contains(testName + "start"))
					{
						//count number of active columns in row
						totalColumn = row.getPhysicalNumberOfCells() -1;
						//Create array of rows and column
						dataSets = new String[totalRow][totalColumn];
					}
					//System.out.println(sheetName + "start");
					if(cell.getStringCellValue().contains(testName + "start") || count ==2)
					{
						System.out.println(sheetName + "start");
						count = 2;
						//Check the cell type  and the format accordingly

						switch (cell.getCellType())
						{
						case Cell.CELL_TYPE_NUMERIC:
							dataSets[i - 1][j++] = cell.getStringCellValue();
							System.out.println(cell.getNumericCellValue());
							break;
						case Cell.CELL_TYPE_STRING:
							if(!cell.getStringCellValue().contains(testName + "start"))
							{
								dataSets[i - 1][j++] = cell.getStringCellValue();
								System.out.println(cell.getNumericCellValue());
							}
							break;
						case Cell.CELL_TYPE_BOOLEAN:
							dataSets[i - 1][j++] = cell.getStringCellValue();
							System.out.println(cell.getNumericCellValue());
							break;
						case Cell.CELL_TYPE_FORMULA:
							dataSets[i - 1][j++] = cell.getStringCellValue();
							System.out.println(cell.getNumericCellValue());
							break;
						}
					}
				}
				System.out.println("");
				i++;
			}
			fis.close();

			//return parseData(dataSets, totalColumn);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;

	}



	public static String setCellData(String value, int RowNum, int ColNum) 
	{
		try 
		{
			row = sheet.getRow(RowNum);
			cell = row.getCell(ColNum);
			if (cell == null) {
				cell = row.createCell(ColNum);
				cell.setCellValue(value);
			} else 
			{
				cell.setCellValue(value);
			}
			// Constant variables Test Data path and Test Data file name
			// FileOutputStream fileOut = new FileOutputStream(path + excel.);
			fileOut = new FileOutputStream(path);
			workbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (Exception e) 
		{

			e.printStackTrace();
			/*
			 * try { // throw (e); return value; } catch (IOException e1) {
			 * e1.printStackTrace(); }
			 */
		}
		return value;
	}

	//This method reads the test data from the Excel cell.
	//We are passing row number and column number as parameters.
	public static String getCellData(int RowNum, int ColNum) {
		try {
			cell = sheet.getRow(RowNum).getCell(ColNum);
			DataFormatter formatter = new DataFormatter();
			String cellData = formatter.formatCellValue(cell);
			return cellData;
		} catch (Exception e) {
			//throw (e);
			e.printStackTrace();
			return "row "+RowNum+" or column "+ColNum +" does not exist  in xls";
		}
	}

	// returns the data from a cell
	public String getCellData(String sheetName,String colName,int rowNum){
		try{
			if(rowNum <=0)
				return "";

			int index = workbook.getSheetIndex(sheetName);
			int col_Num=-1;

			if(index==-1)
				return "";

			sheet = workbook.getSheetAt(index);
			row=sheet.getRow(0);
			for(int i=0;i<row.getLastCellNum();i++)
			{
				//System.out.println(row.getCell(i).getStringCellValue().trim());
				if(row.getCell(i).getStringCellValue().trim().equals(colName.trim()))
					col_Num=i;
			}
			if(col_Num==-1)
				return "";

			sheet = workbook.getSheetAt(index);
			row = sheet.getRow(rowNum-1);
			if(row==null)
				return "";
			cell = row.getCell(col_Num);

			if(cell==null)
				return "";

			if(cell.getCellType()==Cell.CELL_TYPE_STRING)
				return cell.getStringCellValue();
			else if(cell.getCellType()==Cell.CELL_TYPE_NUMERIC || cell.getCellType()==Cell.CELL_TYPE_FORMULA ){

				String cellText  = String.valueOf(cell.getNumericCellValue());

				//long l=Long.parseLong(cellText);
				if (HSSFDateUtil.isCellDateFormatted(cell)) 
				{

					double d = cell.getNumericCellValue();

					Calendar cal =Calendar.getInstance();
					cal.setTime(HSSFDateUtil.getJavaDate(d));
					cellText = (String.valueOf(cal.get(Calendar.YEAR))).substring(2);
					cellText = cal.get(Calendar.DAY_OF_MONTH) + "/" +
							cal.get(Calendar.MONTH)+1 + "/" + 
							cellText;
				}



				return cellText;
			}else if(cell.getCellType()==Cell.CELL_TYPE_BLANK)
				return ""; 
			else 
				return String.valueOf(cell.getBooleanCellValue());

		}
		catch(Exception e){ 			
			e.printStackTrace();
			return "row "+rowNum+" or column "+colName +" does not exist in xls";
		}
	}


	// returns the data from a cell
	public String getCellData(String sheetName,int colNum,int rowNum){
		try{
			if(rowNum <=0)
				return "";

			int index = workbook.getSheetIndex(sheetName);

			if(index==-1)
				return "";


			sheet = workbook.getSheetAt(index);
			row = sheet.getRow(rowNum-1);
			if(row==null)
				return "";
			cell = row.getCell(colNum);
			if(cell==null)
				return "";

			if(cell.getCellType()==Cell.CELL_TYPE_STRING)
				return cell.getStringCellValue();
			else if(cell.getCellType()==Cell.CELL_TYPE_NUMERIC || cell.getCellType()==Cell.CELL_TYPE_FORMULA ){

				String cellText  = String.valueOf(cell.getNumericCellValue());
				if (HSSFDateUtil.isCellDateFormatted(cell)) 
				{
					// format in form of M/D/YY
					double d = cell.getNumericCellValue();

					Calendar cal =Calendar.getInstance();
					cal.setTime(HSSFDateUtil.getJavaDate(d));
					cellText =
							(String.valueOf(cal.get(Calendar.YEAR))).substring(2);
					cellText = cal.get(Calendar.MONTH)+1 + "/" +
							cal.get(Calendar.DAY_OF_MONTH) + "/" +
							cellText;
				}



				return cellText;
			}else if(cell.getCellType()==Cell.CELL_TYPE_BLANK)
				return "";
			else 
				return String.valueOf(cell.getBooleanCellValue());
		}
		catch(Exception e){

			e.printStackTrace();
			return "row "+rowNum+" or column "+colNum +" does not exist  in xls";
		}
	}




	// returns true if data is set successfully else false
	public boolean setCellData(String sheetName,String colName,int rowNum, String data){
		try{
			fis = new FileInputStream(path); 
			workbook = new XSSFWorkbook(fis);

			if(rowNum<=0)
				return false;

			int index = workbook.getSheetIndex(sheetName);
			int colNum=-1;
			if(index==-1)
				return false;
			sheet = workbook.getSheetAt(index);
			row=sheet.getRow(0);
			for(int i=0;i<row.getLastCellNum();i++)
			{
				//System.out.println(row.getCell(i).getStringCellValue().trim());
				if(row.getCell(i).getStringCellValue().trim().equals(colName))
					colNum=i;
			}
			if(colNum==-1)
				return false;
			sheet.autoSizeColumn(colNum); 
			row = sheet.getRow(rowNum-1);
			if (row == null)
				row = sheet.createRow(rowNum-1);
			cell = row.getCell(colNum);	
			if (cell == null)
				cell = row.createCell(colNum);
				cell.setCellValue(data);

			fileOut = new FileOutputStream(path);
			workbook.write(fileOut);
			fileOut.close();	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean setCellDataColor(String sheetName,String colName,int rowNum, String data)
	{
		try{
			fis = new FileInputStream(path);
			//fis = new FileInputStream(new File(System.getProperty("user.dir") + "\\src\\test\\resources\\verifydata\\XlaTrxH.xlsx"));
			//"F:\\Expected.xlsx"));
			workbook = new XSSFWorkbook(fis);
			if(rowNum<=0)
				return false;
			int index = workbook.getSheetIndex(sheetName);
			int colNum=-1;
			if(index==-1)
				return false;
			sheet = workbook.getSheetAt(index);
			row=sheet.getRow(0);
			
			for(int i=0;i<row.getLastCellNum();i++)
			{
				if(row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(colName))
					colNum=i;
			}
			if(colNum==-1)
				return false;
			sheet.autoSizeColumn(colNum);
			row = sheet.getRow(rowNum-1);
			if (row == null)
				row = sheet.createRow(rowNum-1);
			cell = row.getCell(colNum);
			if (cell == null)
				cell = row.createCell(colNum);
			hlink_style = workbook.createCellStyle();
			XSSFFont hlink_font = workbook.createFont();
			hlink_font.setUnderline(XSSFFont.U_SINGLE);
			hlink_font.setColor(IndexedColors.BLUE.getIndex());
			hlink_style.setFont(hlink_font);
			if(data.equals("PASS"))
			{
				hlink_font.setColor(IndexedColors.GREEN.getIndex());
				cell.setCellValue(data);
				cell.setCellStyle(hlink_style);
			}else if(data.equals("FAIL"))
			{
				hlink_font.setColor(IndexedColors.RED.getIndex());
				cell.setCellValue(data);
				cell.setCellStyle(hlink_style);

			}else{
				hlink_font.setColor(IndexedColors.DARK_YELLOW.getIndex());
				cell.setCellValue(data);
				cell.setCellStyle(hlink_style);
			}

			XSSFCreationHelper createHelper = workbook.getCreationHelper();
			fileOut = new FileOutputStream(path);
			//fileOut = new FileOutputStream(new File(System.getProperty("user.dir") +"\\src\\test\\resources\\verifydata\\XlaTrxH.xlsx"));
			//"F:\\Expected.xlsx"));

			workbook.write(fileOut);
			fileOut.close();
		}
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// returns true if data is set successfully else false
	public boolean setCellData(String sheetName,String colName,int rowNum, String data,String url){

		try{
			fis = new FileInputStream(path); 
			workbook = new XSSFWorkbook(fis);

			if(rowNum<=0)
				return false;

			int index = workbook.getSheetIndex(sheetName);
			int colNum=-1;
			if(index==-1)
				return false;


			sheet = workbook.getSheetAt(index);

			row=sheet.getRow(0);
			for(int i=0;i<row.getLastCellNum();i++){

				if(row.getCell(i).getStringCellValue().trim().equalsIgnoreCase(colName))
					colNum=i;
			}

			if(colNum==-1)
				return false;
			sheet.autoSizeColumn(colNum); 
			row = sheet.getRow(rowNum-1);
			if (row == null)
				row = sheet.createRow(rowNum-1);

			cell = row.getCell(colNum);	
			if (cell == null)
				cell = row.createCell(colNum);

			cell.setCellValue(data);
			XSSFCreationHelper createHelper = workbook.getCreationHelper();

			//cell style for hyperlinks

			CellStyle hlink_style = workbook.createCellStyle();
			XSSFFont hlink_font = workbook.createFont();
			hlink_font.setUnderline(XSSFFont.U_SINGLE);
			hlink_font.setColor(IndexedColors.BLUE.getIndex());
			hlink_style.setFont(hlink_font);
			//hlink_style.setWrapText(true);

			XSSFHyperlink link = createHelper.createHyperlink(XSSFHyperlink.LINK_FILE);
			link.setAddress(url);
			cell.setHyperlink(link);
			cell.setCellStyle(hlink_style);

			fileOut = new FileOutputStream(path);
			workbook.write(fileOut);

			fileOut.close();	

		}
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}



	// returns true if sheet is created successfully else false
	public boolean addSheet(String  sheetname){		

		FileOutputStream fileOut;
		try {
			workbook.createSheet(sheetname);	
			fileOut = new FileOutputStream(path);
			workbook.write(fileOut);
			fileOut.close();		    
		} catch (Exception e) {			
			e.printStackTrace();
			return false;
		}
		return true;
	}


	//Set Cell Color
	public boolean cellColor(String sheetName, String columnName)
	{
		FileOutputStream fileOut;
		try {
			CellStyle style = workbook.createCellStyle();
			style.setFillForegroundColor(IndexedColors.GREEN.getIndex());
			style.setFillPattern(CellStyle.BORDER_MEDIUM_DASHED);
			Font font = workbook.createFont();
			font.setColor(IndexedColors.RED.getIndex());
			style.setFont(font);
		}
		catch (Exception e) {			
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// returns true if sheet is removed successfully else false if sheet does not exist
	public boolean removeSheet(String sheetName)
	{		
		int index = workbook.getSheetIndex(sheetName);
		if(index==-1)
			return false;

		FileOutputStream fileOut;
		try {
			workbook.removeSheetAt(index);
			fileOut = new FileOutputStream(path);
			workbook.write(fileOut);
			fileOut.close();		    
		} catch (Exception e) {			
			e.printStackTrace();
			return false;
		}
		return true;
	}

	// returns true if column is created successfully
	public boolean addColumn(String sheetName,String colName)
	{
		try{				
			fis = new FileInputStream(path); 
			workbook = new XSSFWorkbook(fis);
			int index = workbook.getSheetIndex(sheetName);
			if(index==-1)
				return false;

			XSSFCellStyle style = workbook.createCellStyle();
			style.setFillForegroundColor(HSSFColor.GREY_40_PERCENT.index);
			style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

			sheet=workbook.getSheetAt(index);

			row = sheet.getRow(0);
			if (row == null)
				row = sheet.createRow(0);


			if(row.getLastCellNum() == -1)
				cell = row.createCell(0);
			else
				cell = row.createCell(row.getLastCellNum());

			cell.setCellValue(colName);
			cell.setCellStyle(style);

			fileOut = new FileOutputStream(path);
			workbook.write(fileOut);
			fileOut.close();		    

		}catch(Exception e){
			e.printStackTrace();
			return false;
		}

		return true;
	}

	// removes a column and all the contents
	public boolean removeColumn(String sheetName, int colNum) 
	{
		try{
			if(!isSheetExist(sheetName))
				return false;
			fis = new FileInputStream(path); 
			workbook = new XSSFWorkbook(fis);
			sheet=workbook.getSheet(sheetName);
			XSSFCellStyle style = workbook.createCellStyle();
			style.setFillForegroundColor(HSSFColor.GREY_40_PERCENT.index);
			XSSFCreationHelper createHelper = workbook.getCreationHelper();
			style.setFillPattern(HSSFCellStyle.NO_FILL);
			for(int i =0;i<getRowCount(sheetName);i++)
			{
				row=sheet.getRow(i);	
				if(row!=null){
					cell=row.getCell(colNum);
					if(cell!=null){
						cell.setCellStyle(style);
						row.removeCell(cell);
					}
				}
			}
			fileOut = new FileOutputStream(path);
			workbook.write(fileOut);
			fileOut.close();
		}
		catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}


	// find whether sheets exists	
	public boolean isSheetExist(String sheetName)
	{
		int index = workbook.getSheetIndex(sheetName);
		if(index==-1){
			index=workbook.getSheetIndex(sheetName.toUpperCase());
			if(index==-1)
				return false;
			else
				return true;
		}
		else
			return true;
	}


	// returns number of columns in a sheet	
	public int getColumnCount(String sheetName)
	{
		// check if sheet exists
		if(!isSheetExist(sheetName))
			return -1;
		sheet = workbook.getSheet(sheetName);
		row = sheet.getRow(0);

		if(row==null)
			return -1;

		return row.getLastCellNum();
	}

	//String sheetName, String testCaseName,String keyword ,String URL,String message
	public boolean addHyperLink(String sheetName,String screenShotColName,String testCaseName,int index,String url,String message)
	{
		url=url.replace('\\', '/');
		if(!isSheetExist(sheetName))
			return false;
		sheet = workbook.getSheet(sheetName);

		for(int i=2;i<=getRowCount(sheetName);i++)
		{
			if(getCellData(sheetName, 0, i).equalsIgnoreCase(testCaseName))
			{
				setCellData(sheetName, screenShotColName, i+index, message,url);
				break;
			}
		}
		return true; 
	}

	public int getCellRowNum(String sheetName,String colName,String cellValue)
	{
		for(int i=2;i<=getRowCount(sheetName);i++)
		{
			String getCellValue = getCellData(sheetName,colName , i);
			if(getCellValue.trim().equalsIgnoreCase(cellValue.trim()))
			{
				return i;
			}
		}
		return -1;	
	}

	// to run this on stand alone
	public static void main(String arg[]) throws IOException
	{
		ExcelReader datatable = null;
		datatable = new ExcelReader("C:\\CM3.0\\app\\test\\Framework\\AutomationBvt\\src\\config\\xlfiles\\Controller.xlsx");
		for(int col=0 ;col< datatable.getColumnCount("TC5"); col++)
		{
			System.out.println(datatable.getCellData("TC5", col, 1));
		}
	}
}
