package com.smarteinc.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.smarteinc.base.globalLibrary;

public class HomePage extends globalLibrary
{
	globalLibrary seleniumLibrary = new globalLibrary();

	public void searchProduct()
	{
		seleniumLibrary.writeText("searchProductText_XPATH", excel.getCellData("testData", "SearchProduct", 2));
		//seleniumLibrary.click("searchButton_XPATH");			//Click on search button.
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		seleniumLibrary.click("searchProductTextAuto_XPATH");	//Select an item through auto suggestion 
	}

	public void filterPrice()
	{
		seleniumLibrary.click("searchSelectPriceDDMin_XPATH");
		String Minprice = excel.getCellData("testData", "Min_Price", 2);
		driver.findElement(By.xpath("(//select[@class='fPjUPw'])[1]/option[@value='"+Minprice+"']")).click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		String Maxprice = excel.getCellData("testData", "Max_Price", 5);
		seleniumLibrary.isElementPresent("searchSelectPriceDDMax_XPATH");
		driver.findElement(By.xpath("(//select[@class='fPjUPw'])[2]/option[@value='"+Maxprice+"']")).click();
		//seleniumLibrary.click("//select[@class='fPjUPw']/option[@value='"+Maxprice+"']");
	}

	public void selectProcessorBrand()
	{
		seleniumLibrary.isElementPresent("searchCheckBrand_XPATH"); //Wait the Present of an element Processor Brand
		seleniumLibrary.scrollWebElement("searchCheckBrand_XPATH"); //Scroll and Expand Processor Brand 
		for(int brand=0;brand<5;brand++)
		{
			try
			{
				seleniumLibrary.webElementClick("searchCheckBrand_XPATH");
				break;
			}
			catch(Exception StaleElemenetReference)
			{
				StaleElemenetReference.printStackTrace();
			}
		}
		//Store all the Web-element to click on a specific Brand.
		List<WebElement> ProcssorBrand_list = driver.findElements(By.xpath("//div[@class='_2yccxO D0YrLF'][contains(text(),'Processor Brand')]/parent::div/following-sibling::div/child::div/div"));
		//List<WebElement> ProcssorBrand_list = driver.findElements(By.xpath("//div[@class='_4IiNRh _2mtkou']//parent::div[@class='_36jUgy']"));
		int ProcessorBrandCount=ProcssorBrand_list.size();

		for(int Processor=0;Processor<ProcessorBrandCount;Processor++)
		{
			if(ProcssorBrand_list.get(Processor).getAttribute("title").equals("Snapdragon"))
			{

				ProcssorBrand_list.get(Processor).click();
				break;	
			}
		}

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//List out the Product once filtered and collect the details and stored into in excel sheet.
	//Product Name and Price.
	public void setProductDetails()
	{
		List<WebElement> product_list = driver.findElements(By.xpath("//div[@class='_3wU53n']"));
		List<WebElement> productprice_list = driver.findElements(By.xpath("//div[@class='_1vC4OE _2rQ-NK']"));

		System.out.println("Name of the Product " + product_list + "Price: "+ productprice_list);
		String product_name;
		String product_price;
		int int_product_price;
		System.out.println("Product Num:  " + product_list.size());
		for(int i=0;i<product_list.size();i++) 
		{
			try
			{
				product_list.get(i).isDisplayed();
				product_name = product_list.get(i).getText();//Iterate and fetch product name
				excel.setCellData("itemDetails", "ProductName", i+2, product_name);
				product_price = productprice_list.get(i).getText();//Iterate and fetch product price
				product_price = product_price.replaceAll("[^0-9]", "");//Replace anything wil space other than numbers
				int_product_price = Integer.parseInt(product_price);//Convert to Integer
				excel.setCellData("itemDetails", "ProductPrice", i+2, String.valueOf(int_product_price));
			}catch(Exception ProudctList)
			{

			}
		}
	}

}




