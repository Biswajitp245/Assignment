package com.smarteinc.listeners;

import java.io.IOException;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.relevantcodes.extentreports.LogStatus;
import com.smarteinc.base.TestBase;
import com.smarteinc.utilities.TestUtil;
//@author #Biswajit Pattanaik
public class CustomListeners extends TestBase implements ITestListener, ISuiteListener 
{

	public String messageBody;

	private static String getTestMethodName(ITestResult iTestResult) 
	{
		return iTestResult.getMethod().getConstructorOrMethod().getName();
	}

	//@Override
	public void onStart(ITestContext iTestContext) 
	{
		System.out.println("I am in onStart method " + iTestContext.getName());
	}


	//@Override 
	public void onFinish(ITestContext iTestContext) 
	{
		System.out.println("I am in onFinish " + iTestContext.getName()); 
		//test.log(LogStatus.PASS, "I am in onFinish " + iTestContext.getName());
	}


	//@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) 
	{
		System.out.println("Test failed but it is in defined success ratio " + getTestMethodName(iTestResult));
	}

	//@Override
	public void onTestFailure(ITestResult iTestResult) 
	{

		System.setProperty("test-output.html", "false");
		try 
		{
			TestUtil.captureScreenshot();
		} catch (IOException e) 
		{
			e.printStackTrace();
		}

		test.log(LogStatus.FAIL, iTestResult.getName().toUpperCase() + " Failed with exception : " + iTestResult.getThrowable());
		// test.log(LogStatus.FAIL,
		// TestUtil.captureScreenshot().addScreenCapture(TestUtil.screenshotName));
		// test.log(LogStatus.FAIL, TestUtil.captureScreenshot());
		// Update the test result on excel sheet
		//ExcelReader.setCellData("FAILED", ExcelReader.getRowNumber(), ExcelReader.getColumnNumber());
		test.log(LogStatus.FAIL, iTestResult.getName().toUpperCase() + "        FAIL");
		Reporter.log("Click to see Screenshot");
		Reporter.log("<a target=\"_blank\" href=" + TestUtil.screenshotName + ">Screenshot</a>");
		Reporter.log("<br>");
		Reporter.log("<br>");
		Reporter.log("<a target=\"_blank\" href=" + TestUtil.screenshotName + "><img src=" + TestUtil.screenshotName
				+ " height=200 width=200></img></a>");
		report.endTest(test);
		report.flush();
	}

	//@Override
	public void onTestSkipped(ITestResult iTestResult) 
	{
		test.log(LogStatus.SKIP, "Skipping the test" + iTestResult.getName().toUpperCase()+" as the Run mode is NO");
		report.endTest(test); 
		report.flush(); 
	}

	//@Override
	public void onTestStart(ITestResult iTestResult) 
	{
		test = report.startTest(iTestResult.getName().toUpperCase());
		System.out.println("I am in onTestStart method " + getTestMethodName(iTestResult) + "Start");
	}

	//@Override
	public void onTestSuccess(ITestResult iTestResult) 
	{
		System.out.println("I am in onTestSuccess method " + getTestMethodName(iTestResult) + "Succeed");
		test.log(LogStatus.PASS, iTestResult.getName().toUpperCase() + "        PASS");
		report.endTest(test);
		report.flush();
	}

	/*
	@Override public void onFinish(ISuite arg0) 
	{
		
		MonitoringMail mail = new MonitoringMail();
		try 
		{ 
			messageBody = "http://" + InetAddress.getLocalHost().getHostAddress()+":8080/src/test/resources/OFAP_Automation/Extent_Reports/"; 
		} 
		catch(UnknownHostException e) 
		{ 
			e.printStackTrace(); 
		}

		try 
		{ 
			mail.sendMail(TestConfig.server, TestConfig.from, TestConfig.to,TestConfig.subject, messageBody); 
		} 
		catch (AddressException e) 
		{
			e.printStackTrace(); 
		} 
		catch (MessagingException e) 
		{ 
			e.printStackTrace();
		}
	}
*/

	//@Override
	public void onStart(ISuite arg0) 
	{

	}

}
