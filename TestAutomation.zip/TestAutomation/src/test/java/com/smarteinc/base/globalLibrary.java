package com.smarteinc.base;

import static org.testng.Assert.fail;

import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.relevantcodes.extentreports.LogStatus;
import com.smarteinc.utilities.TestUtil;
//@author #Biswajit Pattanaik
public class globalLibrary extends TestBase
{
	public static WebElement dropdown;
	public static Alert alert;

	//Navigate URL Functionality
	public void navigatedURL()
	{
		try 
		{
			driver.manage().window().maximize();
			driver.get(config.getProperty("testsiteurl"));
			log.debug("Navigated to : " + config.getProperty("testsiteurl"));
			test.log(LogStatus.INFO, "Navigated to : " + config.getProperty("testsiteurl"));
			driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")),TimeUnit.SECONDS);
			wait = new WebDriverWait(driver, 10);
		}catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			//Extent Reports
			test.log(LogStatus.FAIL, "Navigation Failed Flipkart:   " + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}	
	}

	//Navigate to BIP Report URL Functionality
	public void biReportLink()
	{
		try 
		{
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.get(config.getProperty("biReportURL"));
			log.debug("Navigated to : " + config.getProperty("biReportURL"));
			test.log(LogStatus.INFO, "Navigated to : " + config.getProperty("biReportURL"));
			driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")),TimeUnit.SECONDS);
			wait = new WebDriverWait(driver, 20);
		}catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.debug("Bi Report URL not as expected: " + e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Bi Report URL not  as expected:   " + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}	
	}

	//Delete Browser History
	public void biReportHistory()
	{
		try 
		{
			driver.manage().deleteAllCookies();
			driver.get("chrome://settings/clearBrowserData");
			driver.findElement(By.xpath("//settings-ui")).sendKeys(Keys.ENTER);
			Thread.sleep(10000);
			wait = new WebDriverWait(driver, 20);
		}catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.debug("Delete All History: " + e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Delete All History:   " + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));

		} catch (InterruptedException e) {
			e.printStackTrace();
		}	
	}

	public String EncodeString(String inputStringEncode) 
	{
		byte[] decodedString = Base64.decodeBase64(inputStringEncode);
		
		//System.out.println("Decoded  String :" + new String (decodedString));
		return new String (decodedString);
	}
	
	public String DecodeString(String inputStringDecode) 
	{
		byte[] decodedString = Base64.decodeBase64(inputStringDecode);
		
		//System.out.println("Decoded  String :" + new String (decodedString));
		return new String (decodedString);
	}
	
	//(Use any three types of locator ends with ["_CSS", "_XPATH", "_ID"]) for all the Methods.
	//Click Method 
	public void click(String locator) 
	{
		try 
		{
			if (locator.endsWith("_CSS")) 
			{
				driver.findElement(By.cssSelector(OR.getProperty(locator))).click();
			} else if (locator.endsWith("_XPATH")) 
			{
				driver.findElement(By.xpath(OR.getProperty(locator))).click();
			} else if (locator.endsWith("_ID")) 
			{
				driver.findElement(By.id(OR.getProperty(locator))).click();
			}
			log.debug("Clicking an element : " + locator);
			//test.log(LogStatus.INFO, "Clicking an element : " + locator);
		} catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Clicking an element : " + e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Clicking on element :  " + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));

		}
	}

	//WabElement Click
	public void webElementClick(String locator)
	{
		try {
			if(locator.endsWith("_CSS")) 
			{ 
				WebElement element = driver.findElement(By.xpath(OR.getProperty(locator)));						
				element.click();
			} else if(locator.endsWith("_XPATH")) 
			{ 
				WebElement element = driver.findElement(By.xpath(OR.getProperty(locator)));						
				element.click(); 
			} else if(locator.endsWith("_ID")) 
			{ 
				WebElement element = driver.findElement(By.xpath(OR.getProperty(locator)));						
				element.click();
			}
			log.debug("Click on a webelement : " + locator);
			test.log(LogStatus.INFO, "Wait for an element : " + locator);
		}catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Click on a webelement :  " + locator + " --- "+ e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Click on a webelement :  " + locator + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
	}
	//Without Clicking Press Keys from Keyboard 
	public void clickKeyboard(Keys keyname) 
	{
		Actions actions = new Actions(driver);
		try 
		{
			actions.sendKeys(keyname).perform();
			log.debug("Function Key Name: " + keyname);
			//test.log(LogStatus.INFO, "Function Key Name:  " + keyname);
		} catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Function Key Name: " + e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Function Key Name:  " + keyname + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));

		}
	}

	//Switch to Frame
	public void switchFrame(int frame) 
	{
		int size;
		try 
		{
			driver.findElements(By.tagName("iframe")).size();
			driver.switchTo().frame(frame);
			log.debug("Frame Name: " + frame);
			System.out.println("Frame Name: " + frame);
			//test.log(LogStatus.INFO, "Frame Name:  " + frame);
		} catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Frame Name: " + frame + " --- "+ e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Frame Name:  " + frame + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
	}

	//Switch to Default Frame
	public void switchDefaultFrame() 
	{
		int size;
		try 
		{
			driver.switchTo().defaultContent();
			log.debug("Switch to Default Frame");
			System.out.println("Switch to Default Frame");
			//test.log(LogStatus.INFO, "Frame Name:  " + frame);
		} catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Switch to Default Frame" + " --- "+ e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Switch to Default Frame" + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
	}

	//(Use any three types of locator ends with ["_CSS", "_XPATH", "_ID"]) for all the Methods.
	//Clear Method can clear any text field, combo-box etc
	public void textClear(String locator) 
	{
		try {
			if (locator.endsWith("_CSS")) {
				driver.findElement(By.cssSelector(OR.getProperty(locator))).clear();
			} else if (locator.endsWith("_XPATH")) {
				driver.findElement(By.xpath(OR.getProperty(locator))).clear();
			} else if (locator.endsWith("_ID")) {
				driver.findElement(By.id(OR.getProperty(locator))).clear();
			}
			log.debug("Name of Clear Textbox: " + locator);
			//test.log(LogStatus.INFO, "Name of Clear Textbox: " + locator);
		}catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Name of Clear Textbox: " + locator + " --- "+ e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Name of Clear Textbox:  " + locator + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
	}

	//WabElementWait [Wait-Click Method] for Visibility Of Element Located 
	public void waitClick(String locator) 
	{
		try {
			if (locator.endsWith("_CSS")) 
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(OR.getProperty(locator)))).click();
			} else if (locator.endsWith("_XPATH")) 
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(OR.getProperty(locator)))).click();
			} else if (locator.endsWith("_ID")) 
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(OR.getProperty(locator)))).click();
			}
			log.debug("Clicking an element : " + locator);
			//test.log(LogStatus.INFO, "Clicking an element : " + locator);
		}
		catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Clicking an element : " + locator + " --- "+ e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Clicking an element :  " + locator + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
	}

	//WabElement [Double-Click Method] for Using Action Class
	public void dblClick(String locator) 
	{
		try {
			Actions actions = new Actions(driver);
			if(locator.endsWith("_CSS")) 
			{ 
				WebElement elementLocator = driver.findElement(By.cssSelector(OR.getProperty(locator)));
				actions.doubleClick(elementLocator).perform();
			} else if(locator.endsWith("_XPATH")) 
			{ 
				WebElement elementLocator = driver.findElement(By.xpath(OR.getProperty(locator)));
				actions.doubleClick(elementLocator).perform();
			} else if(locator.endsWith("_ID")) 
			{ 
				WebElement elementLocator =driver.findElement(By.id(OR.getProperty(locator)));
				actions.doubleClick(elementLocator).perform();
			}
			log.debug("Double clicking an element : " + locator);
			//test.log(LogStatus.INFO, "Double clicking an element : " + locator);
		}
		catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Double clicking an element : " + locator + " --- "+ e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Clicking an element :  " + locator + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
	}

	//Getting an WabElement Using "JavascriptExecutor"
	public void waitWebElement(String locator)
	{
		try {
			if(locator.endsWith("_CSS")) 
			{ 
				WebElement ele = driver.findElement(By.cssSelector(OR.getProperty(locator)));
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].click();", ele); 
			} else if(locator.endsWith("_XPATH")) 
			{ 
				WebElement ele = driver.findElement(By.xpath(OR.getProperty(locator)));
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].click();", ele); 
			} else if
			(locator.endsWith("_ID")) 
			{ 
				WebElement ele = driver.findElement(By.id(OR.getProperty(locator)));
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].click();", ele); 
			}
			log.debug("Wait for an element : " + locator);
			//test.log(LogStatus.INFO, "Wait for an element : " + locator);
		}catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Wait for an element :  " + locator + " --- "+ e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Wait for an element :  " + locator + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
	}

	//Getting an WabElement Using "JavascriptExecutor" Scroll WebElement
	public void scrollWebElement(String locator)
	{
		try
		{
			if(locator.endsWith("_CSS")) 
			{ 
				WebElement ele = driver.findElement(By.cssSelector(OR.getProperty(locator)));
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].scrollIntoView(0);", ele); 
			} else if(locator.endsWith("_XPATH")) 
			{ 
				WebElement ele = driver.findElement(By.xpath(OR.getProperty(locator)));
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].scrollIntoView(0);", ele); 
			} else if
			(locator.endsWith("_ID")) 
			{ 
				WebElement ele = driver.findElement(By.id(OR.getProperty(locator))); 
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].scrollIntoView(0);", ele); 
			}
			log.error("Scroll for an element is:  " + locator);
			test.log(LogStatus.INFO, "Scroll for an element is : " + locator);
		}	catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Scroll for an element is:  " + locator + " --- "+ e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Scroll for an element is:  " + locator + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
	}

	//Write Text into a Web-Element it may be (Text-Box, Combo-Box
	public void writeText(String locator, String value) 
	{
		try
		{
			if (locator.endsWith("_CSS")) {
				driver.findElement(By.cssSelector(OR.getProperty(locator))).sendKeys(value);
			} else if (locator.endsWith("_XPATH")) {
				driver.findElement(By.xpath(OR.getProperty(locator))).sendKeys(value);
			} else if (locator.endsWith("_ID")) {
				driver.findElement(By.id(OR.getProperty(locator))).sendKeys(value);
			}
			log.error("Typing in : " + locator+ " Entered value as:  " + value);
			test.log(LogStatus.INFO, "Typing in :  " + locator + " Entered value as:  " + value);
		}catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Typing in : " + locator+ " Entered value as:  " + value + " --- "+ e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Wait for an element :  " + locator + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
	}

	//Read Text or GetText for a Web-Element
	public String readText(String locator, String text) 
	{
		try
		{
			if (locator.endsWith("_CSS")) {
				text = driver.findElement(By.cssSelector(OR.getProperty(locator))).getText();
			} else if (locator.endsWith("_XPATH")) {
				text = driver.findElement(By.xpath(OR.getProperty(locator))).getText();
			} else if (locator.endsWith("_ID")) {
				text = driver.findElement(By.id(OR.getProperty(locator))).getText();
			}
			log.error("Name of te Web-Element :  " + locator + "    The Text Name is:   " + text);
			//test.log(LogStatus.INFO, "Name of te Web-Element :  " + locator + "    The Text Name is:   " + text);
			return text;
		}catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Name of te Web-Element :  " + locator + "    The Text Name is:   " + text+ e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Wait for an element :  " + locator + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
		return text;
	}

	//Select an element if the dropdown element have option and value
	public void select(String locator, String text) 
	{
		try
		{
			if (locator.endsWith("_CSS")) 
			{
				dropdown = driver.findElement(By.cssSelector(OR.getProperty(locator)));
			} else if (locator.endsWith("_XPATH")) 
			{
				dropdown = driver.findElement(By.xpath(OR.getProperty(locator)));
			} else if (locator.endsWith("_ID")) 
			{
				dropdown = driver.findElement(By.id(OR.getProperty(locator)));
			}

			Select select = new Select(dropdown);
			//select.selectByVisibleText(text);
			select.selectByValue(text);
			log.debug("Selecting from dropdown : " + locator + "   text as " + text);
			//test.log(LogStatus.INFO, "Selecting from dropdown : " + locator + "   text as " + text);
		}catch (NoSuchElementException e) 
		{
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Selecting from dropdown : " + locator + "   text as " + text+ e.getMessage());
			//Extent Reports
			test.log(LogStatus.FAIL, "Selecting from dropdown : " + locator + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
	}

	public void tableWebElement(String locator) 
	{
		WebElement htmltable;
		if(locator.endsWith("_CSS")) 
		{ 
			htmltable = driver.findElement(By.cssSelector(OR.getProperty(locator)));

		} else if(locator.endsWith("_XPATH")) 
		{ 
			htmltable = driver.findElement(By.xpath(OR.getProperty(locator)));
		} else if(locator.endsWith("_ID")) 
		{ 
			htmltable = driver.findElement(By.id(OR.getProperty(locator))); 
		}
		test.log(LogStatus.INFO, " " + locator);
	}

	//Mouse Hover to an element
	public boolean mouseHoverWebTableRead(String locator) throws IOException 
	{
		Actions action = new Actions(driver);
		try {

			if(locator.endsWith("_CSS")) 
			{ 
				WebElement element = driver.findElement(By.cssSelector(OR.getProperty(locator)));
				action.moveToElement(element).build().perform();
			} else if(locator.endsWith("_XPATH")) 
			{ 
				WebElement element = driver.findElement(By.xpath(OR.getProperty(locator)));
				action.moveToElement(element).build().perform();
			} else if(locator.endsWith("_ID")) 
			{ 
				WebElement element = driver.findElement(By.id(OR.getProperty(locator)));
				action.moveToElement(element).build().perform();
			}
			log.debug("Mouse Hover to an element: " + locator);
			test.log(LogStatus.INFO, "Mouse Hover to an element:  " + locator);
			return true;	

		} catch (NoSuchElementException e) 
		{
			TestUtil.captureScreenshot();
			//Extent Reports
			test.log(LogStatus.FAIL, " Mouse Hover to an element: " + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
			return false;
		}

	}

	//Is Element Displayed on the web-page.
	public boolean isElementPresent(String locator) 
	{
		try {
			if (locator.endsWith("_CSS")) {
				driver.findElement(By.cssSelector(OR.getProperty(locator))).isDisplayed();
			} else if (locator.endsWith("_XPATH")) {
				driver.findElement(By.xpath(OR.getProperty(locator))).isDisplayed();
			} else if (locator.endsWith("_ID")) {
				driver.findElement(By.id(OR.getProperty(locator))).isDisplayed();
			}
			log.debug("Element Present or Displayed in the Current Page :  " + locator);
			test.log(LogStatus.INFO, "Element Present or Displayed in the Current Page : " + locator);
			return true;
		} catch (Exception e) {
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			log.error("Element Present or Displayed in the Current Page :  " + locator);
			//Extent Reports
			test.log(LogStatus.FAIL, " Element not Present or Displayed in the Current Page : " + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
			return false;
		}
	}

	public boolean isElementEnabled(String locator) 
	{
		try {
			if (locator.endsWith("_CSS")) {
				driver.findElement(By.cssSelector(OR.getProperty(locator))).isEnabled();
			} else if (locator.endsWith("_XPATH")) {
				driver.findElement(By.xpath(OR.getProperty(locator))).isEnabled();
			} else if (locator.endsWith("_ID")) {
				driver.findElement(By.id(OR.getProperty(locator))).isEnabled();
			}
			test.log(LogStatus.INFO, "Element Enabled in the Current Page : " + locator);
			return true;

		} catch (NoSuchElementException e) {

			try {
				TestUtil.captureScreenshot();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			//Extent Reports
			test.log(LogStatus.FAIL, " Verification failed with exception : " + e.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
			return false;

		}

	}

	public void veriticalScroll() 
	{       		
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("window.scrollBy(0,1000)");
		log.debug("Vertical Scroll Bar Till End :  ");
		test.log(LogStatus.INFO, "Vertical Scroll Bar Till End ");
	}

	public void verifyEquals(String expected, String actual) throws IOException 
	{
		try 
		{
			Assert.assertEquals(actual, expected);
		} catch (Throwable t) 
		{
			TestUtil.captureScreenshot();
			//ReportNG
			Reporter.log("<br>" + "Verification failure : " + t.getMessage() + "<br>");
			Reporter.log("<a target=\"_blank\" href=" + TestUtil.screenshotName + "><img src=" + TestUtil.screenshotName + " height=200 width=200></img></a>");
			Reporter.log("<br>");
			//Extent Reports
			test.log(LogStatus.FAIL, "Verification failed with exception : " + t.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
	}
}
